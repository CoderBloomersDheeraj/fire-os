import wikipedia
import pyttsx3
engine = pyttsx3.init()

command = input("Enter Your Query: ",)

result = wikipedia.summary(command, sentences= 10)
print(result)

engine.say(result)
engine.runAndWait()